<link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('assets/css/plugins.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('assets/css/kaiadmin.min.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('assets/css/toastr.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/select2.min.css')); ?>" />
<?php /**PATH /media/kucingsakti/DATA/alvif/projects/app-pajak/resources/views/layouts/style.blade.php ENDPATH**/ ?>