<?php $accessControl = app('App\Services\AccessControlService'); ?>
<?php
    $menuTree = $accessControl->getMenuHierarchy(Auth::user());
?>

<div class="sidebar" data-background-color="dark">
    <div class="sidebar-logo">
        <div class="logo-header" data-background-color="dark">
            <a href="/" class="logo">
                <h5 class="text-white">PAJAK</h5>
            </a>
            <div class="nav-toggle">
                <button class="btn btn-toggle toggle-sidebar">
                    <i class="gg-menu-right"></i>
                </button>
                <button class="btn btn-toggle sidenav-toggler">
                    <i class="gg-menu-left"></i>
                </button>
            </div>
            <button class="topbar-toggler more">
                <i class="gg-more-vertical-alt"></i>
            </button>
        </div>
    </div>
    <div class="sidebar-wrapper scrollbar scrollbar-inner">
        <div class="sidebar-content">
            <ul class="nav nav-secondary">
                <?php $__currentLoopData = $menuTree; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $hasChildren = !empty($menu['children']);
                        $isActive = false;
                        
                        // Check active state
                        if ($menu['route_name'] && Request::routeIs($menu['route_name'])) {
                            $isActive = true;
                        } elseif ($hasChildren) {
                            foreach ($menu['children'] as $child) {
                                if ($child['route_name'] && Request::routeIs($child['route_name'])) {
                                    $isActive = true;
                                    break;
                                }
                            }
                        }
                    ?>

                    <?php if(isset($menu['type']) && $menu['type'] === 'section'): ?>
                        <li class="nav-section">
                            <span class="sidebar-mini-icon">
                                <i class="fa fa-ellipsis-h"></i>
                            </span>
                            <h4 class="text-section"><?php echo e($menu['name']); ?></h4>
                        </li>
                    <?php elseif($hasChildren): ?>
                        <li class="nav-item <?php echo e($isActive ? 'active submenu' : ''); ?>">
                            <a data-bs-toggle="collapse" href="#<?php echo e($menu['slug']); ?>">
                                <i class="<?php echo e($menu['icon'] ?? 'fas fa-layer-group'); ?>"></i>
                                <p><?php echo e($menu['name']); ?></p>
                                <span class="caret"></span>
                            </a>
                            <div class="collapse <?php echo e($isActive ? 'show' : ''); ?>" id="<?php echo e($menu['slug']); ?>">
                                <ul class="nav nav-collapse">
                                    <?php $__currentLoopData = $menu['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="<?php echo e($child['route_name'] && Request::routeIs($child['route_name']) ? 'active' : ''); ?>">
                                            <a href="<?php echo e($child['route_name'] ? route($child['route_name']) : '#'); ?>">
                                                <span class="sub-item"><?php echo e($child['name']); ?></span>
                                            </a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </li>
                    <?php else: ?>
                        <li class="nav-item <?php echo e($isActive ? 'active' : ''); ?>">
                            <a href="<?php echo e($menu['route_name'] ? route($menu['route_name']) : '#'); ?>" class="collapsed">
                                <i class="<?php echo e($menu['icon'] ?? 'fas fa-home'); ?>"></i>
                                <p><?php echo e($menu['name']); ?></p>
                            </a>
                        </li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
</div>

<?php /**PATH /media/kucingsakti/DATA/alvif/projects/app-pajak/resources/views/layouts/sidebar.blade.php ENDPATH**/ ?>