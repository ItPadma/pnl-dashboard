<footer class="footer">
    <div class="container-fluid d-flex justify-content-between">
        <div class="copyright">
            2024, IT OTB Team
        </div>
    </div>
</footer>
